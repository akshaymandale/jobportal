<?php
session_start();
require 'config/database.php';

// Check if user is logged in
$logged_in_username = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : null;


// Get search parameters
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
$location = isset($_GET['location']) ? trim($_GET['location']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$min_salary = isset($_GET['min_salary']) && $_GET['min_salary'] !== '' ? (int) $_GET['min_salary'] : 0;
$max_salary = isset($_GET['max_salary']) && $_GET['max_salary'] !== '' ? (int) $_GET['max_salary'] : 1000000;

try {
    // Fetch jobs with search filters
    $query = "
        SELECT j.id, j.title, j.salary, j.location, j.category, j.description, c.name 
        FROM job_posts j 
        JOIN companies c ON j.company_id = c.id
        WHERE (j.title LIKE :keyword OR j.description LIKE :keyword OR :keyword = '')
        AND (j.location LIKE :location OR :location = '')
        AND (j.category = :category OR :category = '')
        AND (j.salary BETWEEN :min_salary AND :max_salary)
    ";

    $stmt = $conn->prepare($query);
    $stmt->execute([
        'keyword' => "%$keyword%",
        'location' => "%$location%",
        'category' => $category,
        'min_salary' => $min_salary,
        'max_salary' => $max_salary
    ]);

    $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check applied jobs only if user is logged in as an applicant
    $applied_jobs = [];
    if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'applicant') {
        $user_id = $_SESSION['user_id'];
        $applied_query = "SELECT job_id FROM applications WHERE user_id = :user_id";
        $applied_stmt = $conn->prepare($applied_query);
        $applied_stmt->execute(['user_id' => $user_id]);
        $applied_jobs = $applied_stmt->fetchAll(PDO::FETCH_COLUMN);
    }
} catch (PDOException $e) {
    die("Error fetching jobs: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Listings</title>
</head>
<body>

<h1>Job Listings</h1>

<!-- Show logged-in user -->
<?php
if ($logged_in_username): ?>
    <p>Welcome, <strong><?php echo htmlspecialchars($logged_in_username); ?></strong>! 
        <a href="auth/logout.php"><button>Logout</button></a>
    </p>
<?php else: ?>
    <a href="auth/login.php"><button>Login</button></a>
    <a href="auth/register.php"><button>Register</button></a>
<?php endif; ?>

<!-- Search Form -->
<form action="index.php" method="GET">
    <input type="text" name="keyword" placeholder="Keyword" value="<?php echo htmlspecialchars($keyword); ?>">
    <input type="text" name="location" placeholder="Location" value="<?php echo htmlspecialchars($location); ?>">
    <input type="text" name="category" placeholder="Category" value="<?php echo htmlspecialchars($category); ?>">
    <input type="number" name="min_salary" placeholder="Min Salary" value="<?php echo htmlspecialchars($min_salary); ?>">
    <input type="number" name="max_salary" placeholder="Max Salary" value="<?php echo htmlspecialchars($max_salary); ?>">
    <button type="submit">Search</button>
</form>

<!-- Display Jobs -->
<?php if ($jobs): ?>
    <ul>
        <?php foreach ($jobs as $job): ?>
            <li>
                <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                <p>Company: <?php echo htmlspecialchars($job['name']); ?></p>
                <p>Salary: $<?php echo htmlspecialchars($job['salary']); ?></p>
                <p>Location: <?php echo htmlspecialchars($job['location']); ?></p>
                <p>Category: <?php echo htmlspecialchars($job['category']); ?></p>
                <p>Description: <?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                
                <!-- Apply Button Logic -->
                <?php if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'applicant'): ?>
                    <?php if (in_array($job['id'], $applied_jobs)): ?>
                        <button disabled>Applied</button>
                    <?php else: ?>
                        <a href="apply_job.php?job_id=<?php echo $job['id']; ?>"><button>Apply Now</button></a>
                    <?php endif; ?>
                <?php elseif (!isset($_SESSION['user_id'])): ?>
                    <a href="auth/login.php"><button>Login to Apply</button></a>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No jobs match your criteria.</p>
<?php endif; ?>

</body>
</html>
