<?php
require '../config/database.php';
require '../helpers/jwt.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $headers = getallheaders();
    $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

    $decoded = verify_jwt($token);
    if (!$decoded || $decoded->role !== 'applicant') {
        echo json_encode(["status" => "error", "message" => "Unauthorized"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"), true);
    if (!isset($data['job_id'])) {
        echo json_encode(["status" => "error", "message" => "Missing job_id"]);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO applications (user_id, job_id) VALUES (?, ?)");
    if ($stmt->execute([$decoded->user_id, $data['job_id']])) {
        echo json_encode(["status" => "success", "message" => "Application submitted"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to apply"]);
    }
}
?>
