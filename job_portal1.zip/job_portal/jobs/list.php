<?php
require '../config/database.php';

header("Content-Type: application/json");

$category = isset($_GET['category']) ? $_GET['category'] : null;
$salary = isset($_GET['salary']) ? $_GET['salary'] : null;
$location = isset($_GET['location']) ? $_GET['location'] : null;

$query = "SELECT j.id, j.title, c.name AS company, j.salary, j.location, j.description, j.category, j.created_at 
          FROM job_posts j 
          JOIN companies c ON j.company_id = c.id 
          WHERE 1";

$params = [];

if ($category) {
    $query .= " AND j.category = ?";
    $params[] = $category;
}
if ($salary) {
    $query .= " AND j.salary >= ?";
    $params[] = $salary;
}
if ($location) {
    $query .= " AND j.location LIKE ?";
    $params[] = "%$location%";
}

$stmt = $conn->prepare($query);
$stmt->execute($params);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(["status" => "success", "jobs" => $jobs]);
?>
