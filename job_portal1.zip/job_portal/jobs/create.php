<?php
require '../config/database.php';
require '../helpers/jwt.php';

header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $headers = getallheaders();
    $token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

    $decoded = verify_jwt($token);
    if (!$decoded || $decoded->role !== 'employer') {
        echo json_encode(["status" => "error", "message" => "Unauthorized"]);
        exit;
    }

    $data = json_decode(file_get_contents("php://input"), true);
    if (!isset($data['title'], $data['salary'], $data['location'], $data['description'], $data['category'])) {
        echo json_encode(["status" => "error", "message" => "Missing required fields"]);
        exit;
    }

    $stmt = $conn->prepare("INSERT INTO job_posts (title, company_id, salary, location, description, category) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$data['title'], $decoded->user_id, $data['salary'], $data['location'], $data['description'], $data['category']])) {
        echo json_encode(["status" => "success", "message" => "Job posted successfully"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to post job"]);
    }
}
?>
