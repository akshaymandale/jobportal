<?php
require '../config/database.php';
require '../helpers/jwt.php';

header("Content-Type: application/json");

$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

$decoded = verify_jwt($token);
if (!$decoded || ($decoded->role !== 'employer' && $decoded->role !== 'admin')) {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$stmt = $conn->prepare("SELECT a.id, u.name AS applicant, j.title AS job, a.status, a.applied_at 
                        FROM applications a 
                        JOIN users u ON a.user_id = u.id 
                        JOIN job_posts j ON a.job_id = j.id 
                        WHERE j.company_id = ?");
$stmt->execute([$decoded->user_id]);
$applications = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(["status" => "success", "applications" => $applications]);
?>
