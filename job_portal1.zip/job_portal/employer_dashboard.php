<?php
session_start();
require 'config/database.php';

// Ensure employer is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'employer') {
    header("Location: auth/login.php");
    exit();
}

$employer_id = $_SESSION['user_id'];

try {
    // Fetch jobs posted by employer
    $query = "
        SELECT j.id, j.title, j.salary, j.location, j.category, j.description 
        FROM job_posts j 
        WHERE j.company_id = :employer_id
    ";
    $stmt = $conn->prepare($query);
    $stmt->execute(['employer_id' => $employer_id]);
    $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch applications for employer's jobs
    $applications_query = "
        SELECT a.job_id, a.user_id, u.name, a.status 
        FROM applications a
        JOIN users u ON a.user_id = u.id
        JOIN job_posts j ON a.job_id = j.id
        WHERE j.company_id = :employer_id
    ";

    //echo ($applications_query);
    $app_stmt = $conn->prepare($applications_query);
    $app_stmt->execute(['employer_id' => $employer_id]);
    $applications = $app_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error fetching dashboard data: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employer Dashboard</title>
</head>
<body>

<h1>Employer Dashboard</h1>
<p>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?>! <a href="auth/logout.php"><button>Logout</button></a></p>

<h2>Your Job Listings</h2>
<?php if ($jobs): ?>
    <ul>
        <?php foreach ($jobs as $job): ?>
            <li>
                <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                <p>Salary: $<?php echo htmlspecialchars($job['salary']); ?></p>
                <p>Location: <?php echo htmlspecialchars($job['location']); ?></p>
                <p>Category: <?php echo htmlspecialchars($job['category']); ?></p>
                <p>Description: <?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No jobs posted yet.</p>
<?php endif; ?>

<h2>Applications Received</h2>
<?php if ($applications): ?>
    <ul>
        <?php foreach ($applications as $application): ?>
            <li>
                <p>Job ID: <?php echo htmlspecialchars($application['job_id']); ?></p>
                <p>Applicant: <?php echo htmlspecialchars($application['name']); ?></p>
                <p>Status: <?php echo htmlspecialchars($application['status']); ?></p>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No applications received yet.</p>
<?php endif; ?>

</body>
</html>
