<?php
require '../config/database.php';
require '../helpers/jwt.php';

header("Content-Type: application/json");

$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

$decoded = verify_jwt($token);
if (!$decoded) {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Fetch user details
    $stmt = $conn->prepare("SELECT name, email, role FROM users WHERE id = ?");
    $stmt->execute([$decoded->user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(["status" => "success", "user" => $user]);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update profile
    $data = json_decode(file_get_contents("php://input"), true);
    if (!isset($data['name']) || !isset($data['email'])) {
        echo json_encode(["status" => "error", "message" => "Missing fields"]);
        exit;
    }

    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
    if ($stmt->execute([$data['name'], $data['email'], $decoded->user_id])) {
        echo json_encode(["status" => "success", "message" => "Profile updated"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to update"]);
    }
}
?>
