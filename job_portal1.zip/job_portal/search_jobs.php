<?php
session_start();
require 'config/database.php';

// Get search parameters
$keyword = isset($_GET['keyword']) ? trim($_GET['keyword']) : '';
$location = isset($_GET['location']) ? trim($_GET['location']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';
$min_salary = isset($_GET['min_salary']) && $_GET['min_salary'] !== '' ? (int) $_GET['min_salary'] : 0;
$max_salary = isset($_GET['max_salary']) && $_GET['max_salary'] !== '' ? (int) $_GET['max_salary'] : 1000000;

try {
    // Fetch job listings
    $query = "
        SELECT j.id, j.title, j.salary, j.location, j.description, j.category, c.name 
        FROM job_posts j 
        JOIN companies c ON j.company_id = c.id
        WHERE (j.title LIKE :keyword OR j.description LIKE :keyword OR :keyword = '')
        AND (j.location LIKE :location OR :location = '')
        AND (j.category = :category OR :category = '')
        AND (j.salary BETWEEN :min_salary AND :max_salary)
    ";

    $stmt = $conn->prepare($query);
    $stmt->execute([
        'keyword' => "%$keyword%",
        'location' => "%$location%",
        'category' => $category,
        'min_salary' => $min_salary,
        'max_salary' => $max_salary
    ]);

    $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Check applied jobs if user is logged in
    $applied_jobs = [];
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
        $applied_query = "SELECT job_id FROM applications WHERE user_id = :user_id";
        $applied_stmt = $conn->prepare($applied_query);
        $applied_stmt->execute(['user_id' => $user_id]);
        $applied_jobs = $applied_stmt->fetchAll(PDO::FETCH_COLUMN);
    }

} catch (PDOException $e) {
    die("Error fetching jobs: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Jobs</title>
</head>
<body>

<h1>Search Jobs</h1>

<form action="search_jobs.php" method="GET">
    <input type="text" name="keyword" placeholder="Keyword" value="<?php echo htmlspecialchars($keyword); ?>">
    <input type="text" name="location" placeholder="Location" value="<?php echo htmlspecialchars($location); ?>">
    <input type="text" name="category" placeholder="Category" value="<?php echo htmlspecialchars($category); ?>">
    <input type="number" name="min_salary" placeholder="Min Salary" value="<?php echo htmlspecialchars($min_salary); ?>">
    <input type="number" name="max_salary" placeholder="Max Salary" value="<?php echo htmlspecialchars($max_salary); ?>">
    <button type="submit">Search</button>
</form>

<a href="index.php"><button>Back to Home</button></a>

<?php if ($jobs): ?>
    <ul>
        <?php foreach ($jobs as $job): ?>
            <li>
                <h3><?php echo htmlspecialchars($job['title']); ?></h3>
                <p>Company: <?php echo htmlspecialchars($job['name']); ?></p>
                <p>Salary: $<?php echo htmlspecialchars($job['salary']); ?></p>
                <p>Location: <?php echo htmlspecialchars($job['location']); ?></p>
                <p>Category: <?php echo htmlspecialchars($job['category']); ?></p>
                <p>Description: <?php echo nl2br(htmlspecialchars($job['description'])); ?></p>
                
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if (in_array($job['id'], $applied_jobs)): ?>
                        <button disabled>Applied</button>
                    <?php else: ?>
                        <a href="apply_job.php?job_id=<?php echo $job['id']; ?>"><button>Apply Now</button></a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="auth/login.php"><button>Login to Apply</button></a>
                <?php endif; ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p>No jobs match your criteria.</p>
<?php endif; ?>

</body>
</html>
