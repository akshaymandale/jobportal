<?php
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

const SECRET_KEY = "your_secret_key";

function generate_jwt($payload) {
    return JWT::encode($payload, SECRET_KEY, 'HS256');
}

function verify_jwt($token) {
    try {
        return JWT::decode($token, new Key(SECRET_KEY, 'HS256'));
    } catch (Exception $e) {
        return false;
    }
}
?>
