<?php
require '../config/database.php';
require '../helpers/jwt.php';

header("Content-Type: application/json");

$headers = getallheaders();
$token = isset($headers['Authorization']) ? str_replace('Bearer ', '', $headers['Authorization']) : '';

$decoded = verify_jwt($token);
if (!$decoded || ($decoded->role !== 'employer' && $decoded->role !== 'admin')) {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$query = "SELECT j.id, j.title, j.salary, j.location, j.category, COUNT(a.id) AS applications 
          FROM job_posts j 
          LEFT JOIN applications a ON j.id = a.job_id 
          WHERE j.company_id = ? 
          GROUP BY j.id";
$stmt = $conn->prepare($query);
$stmt->execute([$decoded->user_id]);
$jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode(["status" => "success", "jobs" => $jobs]);
?>
