<?php
require 'config/database.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    die("You must be logged in to apply for a job.");
}

if (!isset($_GET['job_id'])) {
    die("Invalid job ID.");
}

$user_id = $_SESSION['user_id'];
$job_id = $_GET['job_id'];

// Check if the user has already applied
$stmt = $conn->prepare("SELECT * FROM applications WHERE user_id = ? AND job_id = ?");
$stmt->execute([$user_id, $job_id]);
if ($stmt->rowCount() > 0) {
    die("You have already applied for this job.");
}

// Insert the application
$stmt = $conn->prepare("INSERT INTO applications (user_id, job_id, status) VALUES (?, ?, 'pending')");
if ($stmt->execute([$user_id, $job_id])) {
    echo "Application submitted successfully.";
} else {
    echo "Failed to submit application.";
}
?>
