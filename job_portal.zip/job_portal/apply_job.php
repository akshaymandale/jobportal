<?php
session_start();
require 'config/database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    $_SESSION['error_message'] = "You must be logged in to apply for a job.";
    header("Location: auth/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;

if ($job_id <= 0) {
    $_SESSION['error_message'] = "Invalid job ID.";
    header("Location: index.php");
    exit();
}

try {
    // Check if the user has already applied for this job
    $checkStmt = $conn->prepare("SELECT id FROM applications WHERE user_id = ? AND job_id = ?");
    $checkStmt->execute([$user_id, $job_id]);
    if ($checkStmt->rowCount() > 0) {
       $_SESSION['error_message'] = "You have already applied for this job.";
        header("Location: index.php");
        exit();
    }

    // Insert the application
    $stmt = $conn->prepare("INSERT INTO applications (user_id, job_id, status) VALUES (?, ?, 'Pending')");
    $stmt->execute([$user_id, $job_id]);

    $_SESSION['success_message'] = "Job applied successfully!";
    header("Location: employer_dashboard.php");
    exit();

} catch (PDOException $e) {
    $_SESSION['error_message'] = "Error applying for job: " . $e->getMessage();
    header("Location: index.php");
    exit();
}
?>
