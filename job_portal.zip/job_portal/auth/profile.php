<?php
require '../config/database.php';
require '../helpers/jwt.php';

header("Content-Type: application/json");

// Get token from header
$headers = getallheaders();
if (!isset($headers['Authorization'])) {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$token = str_replace("Bearer ", "", $headers['Authorization']);
$user = verify_jwt($token);

if (!$user) {
    echo json_encode(["status" => "error", "message" => "Invalid token"]);
    exit;
}

echo json_encode(["status" => "success", "user" => $user]);
?>
