<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login - Job Portal</title>
    <link rel="stylesheet" href="../assets/styles.css">
</head>
<body>
    <header>
        <h1>Login</h1>
        <nav>
            <a href="../index.php">Home</a>
            <a href="register.php">Register</a>
        </nav>
    </header>

    <main>
        <form action="process_login.php" method="POST">
            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Password:</label>
            <input type="password" name="password" required>

            <button type="submit">Login</button>
        </form>
    </main>
</body>
</html>
