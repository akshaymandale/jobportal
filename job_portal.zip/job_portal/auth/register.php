<!DOCTYPE html>
<html lang="en">
<head>
    <title>Register - Job Portal</title>
    <link rel="stylesheet" href="../assets/styles.css">
</head>
<body>
    <header>
        <h1>Register</h1>
        <nav>
            <a href="../index.php">Home</a>
            <a href="login.php">Login</a>
        </nav>
    </header>

    <main>
        <form action="process_register.php" method="POST">
            <label>Name:</label>
            <input type="text" name="name" required>

            <label>Email:</label>
            <input type="email" name="email" required>

            <label>Password:</label>
            <input type="password" name="password" required>

            <label>Role:</label>
            <select name="role">
                <option value="applicant">Applicant</option>
                <option value="employer">Employer</option>
            </select>

            <button type="submit">Register</button>
        </form>
    </main>
</body>
</html>
