<?php
require 'config/database.php';

if (!isset($_GET['id'])) {
    die("Job not found.");
}

$stmt = $conn->prepare("SELECT job_posts.*, companies.name as company_name FROM job_posts JOIN companies ON job_posts.company_id = companies.id WHERE job_posts.id = ?");
$stmt->execute([$_GET['id']]);
$job = $stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= $job['title'] ?> - Job Details</title>
    <link rel="stylesheet" href="assets/styles.css">
</head>
<body>
    <header>
        <h1><?= $job['title'] ?></h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="auth/login.php">Login</a>
            <a href="auth/register.php">Register</a>
        </nav>
    </header>

    <main>
        <h2>Company: <?= $job['company_name'] ?></h2>
        <p>Location: <?= $job['location'] ?></p>
        <p>Salary: $<?= number_format($job['salary']) ?></p>
        <p><?= $job['description'] ?></p>
        <a href="apply.php?job_id=<?= $job['id'] ?>">Apply Now</a>
    </main>
</body>
</html>
